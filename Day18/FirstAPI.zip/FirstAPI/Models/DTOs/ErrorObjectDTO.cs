namespace FirstAPI.Models.DTOs.DoctorSpecialities
{
    public class ErrorObjectDTO
    {
        public int ErrorNumber { get; set; }
        public string ErrorMessage { get; set; }
    }
}