namespace FirstAPI.Models.DTOs.DoctorSpecialities
{
    public class SpecialityAddRequestDto
    {
        public string Name { get; set; } = string.Empty;
    }
}