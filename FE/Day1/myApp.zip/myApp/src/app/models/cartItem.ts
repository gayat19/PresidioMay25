export class CartItem{
    constructor(public Id:Number=0,public Count:number=0)
    {

    }
}